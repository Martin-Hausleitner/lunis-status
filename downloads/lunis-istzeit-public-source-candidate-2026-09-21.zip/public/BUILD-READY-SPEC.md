# Lunis 6-Pro One-Shot Website + Marktbericht — build-ready spec

Status: **Planung/Spezifikation**. Dieses Dokument behauptet weder fertige Website,
laufende One-Shots noch Produktions- oder E2E-Reife. Es bündelt die fünf Lane-Artefakte
und die nachgereichten Pflichtpunkte.

## 1. Ziel und Leser

Die Auslieferung besteht aus einer lokal baubaren Website und einem gebrandeten A4-PDF
mit drei Einstiegen: (a) Management in Klartext, (b) IT mit reproduzierbaren Belegen,
(c) Marktvergleich mit Methode, Quellen und Bandbreiten. Jede Aussage trägt Status
`gemessen`, `belegt`, `geschätzt`, `Vorschlag` oder `offen`.

Verbindliche Grundlagen:

- [IA-/Content-Modell](ia_content_model/IA-CONTENT-MODELL.md)
- [Drei Visualrichtungen](visual_directions/visual-directions.md)
- [Provenienz-/Datenvertrag](provenance_schema/PROVENANCE-DATA-CONTRACT.md)
- [E2E-/Accessibility-Testplan](e2e_accessibility/INTERACTIVE_E2E_ACCESSIBILITY_TESTPLAN.md)
- [Editorial-Syntheseplan](editorial_synthesis/EDITORIAL-SYNTHESE-PLAN.md)
- [JSON-Schema](provenance_schema/provenance.schema.json)

## 2. Seitenbaum und Pflichtmodule

1. **Start / Executive Summary** — Was gebaut/fundiert gefunden wurde, Statusampel,
   Plain-Language-Erklärung, Glossar-Link, wichtigste Einschränkungen.
2. **Management** — Nutzen, Zeit-/Kostenrahmen, Risiken, Entscheidungen; Schätzungen
   immer mit Formel und Bandbreite.
3. **IT / Beweisführung** — Addons, Tests, Architektur, bekannte Lücken, Screenshots,
   One-Shot-Ledger, Reproduktionsbefehle und Commit-/Tag-Referenzen.
4. **Marktbericht** — Vergleichswege, datierte Quellen, Methodik, Unsicherheit,
   kein Festpreis- oder Produktreifeversprechen.
5. **Showcase** — nur ausgewählte, belegte Beispiele mit Screenshot, Kurztext,
   Quelle, Provenienz und Status.
6. **Hard-M-11 / Kira Garage / CAD / EDV-Hausleitner / Lunis-Versionen** — eigener
   Index. Jeder Eintrag hat `item_id`, Version/Datum, Original-vs-Rekonstruktion,
   Quelle, Hash, Größe, Lizenz, öffentliche/private Sichtbarkeit, Download-Eligibility
   und Ausschlussgrund (falls ausgeschlossen).
7. **Downloads / Quellen** — Source-/ZIP-Center mit getrennten Tabs `public` und
   `internal`. Kein interner Pfad, privater Link, Kunde, Token, Passwort oder
   Rohtranskript darf in `public` auftauchen.
8. **Methodik / Selbstkontrolle** — Regelprüfung gegen eigene Logs, Verstöße
   ungeschönt, offene Punkte, R133/fehlende Artefakte explizit.
9. **Appendix / Glossar / JSON** — Datenvertrag, Claim-Register, Zeitledger,
   Prüfsummen und exportierbare maschinenlesbare Metadaten.

## 3. One-Shot- und Zeitledger

Für jeden 6-Pro- oder Instant-Lauf wird ein unveränderlicher Datensatz erfasst:

```json
{
  "shot_id": "PR1",
  "mode": "instant|6-pro",
  "job_id": null,
  "started_at": null,
  "ended_at": null,
  "elapsed_seconds": null,
  "status": "open",
  "rehearsal_status": "open",
  "evidence_refs": [],
  "uncertainty": "open"
}
```

`null` ist korrekt, solange kein direktes Beweissignal existiert; niemals aus
Aufrufzahlen oder Prozesssichtbarkeit ableiten. Der Bericht weist getrennt aus:

- Summe Agent-Wall-Clock (gemessene Intervalle, Überlappung sichtbar),
- menschliche Arbeitszeit/Kosten nur als ausdrücklich markierte Schätzung mit
  Rechenweg und Bandbreite,
- Warte-, Brücken- und Wechselzeiten separat; ein Fenster mit Systempause wird nicht
  als reiner Modellwechselpreis ausgegeben.

## 4. Branding und Visualentscheidung

Primäre Auswahl für den ersten Build: **Calm Evidence**; die beiden Alternativen
bleiben als dokumentierte Varianten im Design-Appendix. Tokens werden aus dem
vorhandenen Lunis-Kit übernommen; Original-Logo, UI-Akzent und Odoo-Override werden
getrennt geführt. Jede Markenreferenz trägt `original`, `reconstructed` oder `derived`.
Versionsevolution (inkl. abweichender eingebetteter älterer Brand-Studio-Stände) wird
als Timeline mit Quelle gezeigt, nicht still vereinheitlicht. Kein Dark-Mode-, Live-
oder E2E-Claim ohne frischen Beleg.

## 5. Privacy- und Download-Gate

Vor jedem öffentlichen Build:

1. Provenienzschema validieren; Claim-Register muss auf erlaubte Locator zeigen.
2. Hash, Bytegröße, Lizenz und Include/Exclude-Entscheid für jeden Download erfassen.
3. Public-Filter ausführen; private Berichte, ZB-15, lokale Pfade, IPs,
   Kundennamen, Beträge, Credentials und Rohtranskripte müssen ausgeschlossen sein.
4. Generated output auf verbotene Muster und kaputte Links scannen.
5. Erst danach Screenshot und Veröffentlichung; bei fehlender Quelle `open`, nicht
   „bestätigt“.

## 6. Browser-/E2E-Abnahme

Die Ausführung folgt dem separaten Testplan und ausschließlich Codex Computer Use.
Pflicht-Viewports: 320×568, 375×812, 768×1024, 1024×768, 1440×900. Für jede
Hauptseite werden Screenshot, URL/Route, Timestamp, Viewport und Build-Hash abgelegt.
Ohne Screenshot ist eine visuelle Behauptung nicht abnahmefähig. Testplan und
Screenshots dürfen erst nach Privacy-Gate als öffentlich markiert werden.

## 7. Acceptance-Matrix

| Gate | Nachweis | PASS-Kriterium | Status jetzt |
|---|---|---|---|
| IA-01 | Seitenbaum + Leserpfade | alle 3 Zielgruppen, Plain Language + IT-Belege | SPEC READY |
| VIS-01 | 3 Designvarianten | unterscheidbar, Lunis-Evidenz referenziert | SPEC READY |
| DATA-01 | JSON-Schema | `json.tool`/Schema-Validator grün | PASS (Schema) |
| TRACE-01 | Claim-Register | jede Aussage → Locator → Evidence → Status | READY TO BUILD |
| PRIV-01 | Filterreport | keine privaten Pfade/Identitäten/Secrets öffentlich | NOT RUN (build fehlt) |
| IDX-01 | Hard-M-11/Kira/CAD/EDV/Lunis-Index | Version, Hash, Lizenz, Sichtbarkeit, Downloadentscheidung je Eintrag | READY TO BUILD |
| TIME-01 | One-shot ledger | Start/Ende/Elapsed je Lauf; Wall-clock getrennt von Schätzung | READY TO BUILD |
| E2E-01 | Codex-Computer-Use-Screenshots | alle Seiten/5 Viewports, keine Behauptung ohne Bild | NOT RUN (keine finale URL) |
| A11Y-01 | Tastatur/Focus/Contrast | Testplan A11Y-01..07 erfüllt | NOT RUN |
| PDF-01 | A4 export | gebrandet, paginiert, Quellen/Status erhalten | NOT RUN |
| SELF-01 | Selbstkontrolle | Logs gegen Regeln geprüft; Verstöße sichtbar | READY TO BUILD |

## 8. Build-Reihenfolge und Stop-Regeln

1. Quellen-/Index-Inventar und One-shot-Ledger ausfüllen.
2. Content-Struktur und ausgewählte Visualrichtung implementieren.
3. Public/Private-Filter und Provenienz-Gates ausführen.
4. Lokale Website bauen; erst danach Codex-Computer-Use-Screenshots aufnehmen.
5. PDF exportieren und gegen dieselben Claims/Quellen prüfen.
6. Bei fehlender URL, fehlendem Screenshot, widersprüchlicher `job_id`, NO-GO-
   Rehearsal oder Privacy-Leak: Status bleibt offen/blocked; keine Produktions- oder
   E2E-Aussage, kein Push/Publish/Mail.

