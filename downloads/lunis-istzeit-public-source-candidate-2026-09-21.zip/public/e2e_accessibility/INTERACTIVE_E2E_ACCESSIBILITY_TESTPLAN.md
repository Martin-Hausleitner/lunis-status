# Interaktiver Website-/E2E-/Accessibility-/Responsive-Testplan

**Status:** Testplan erstellt, Ausführung noch nicht erfolgt  
**Scope:** spätere Prüfung einer konkret gelieferten Website/Preview ausschließlich mit Codex Computer Use  
**Quelle:** vorhandene Artefakte im Run `oneshot-6pro-20260921`

## 1. Artefakt-Basis und Grenzen

Zum Zeitpunkt der Erstellung sind unter `inventory/` und `research/` keine Dateien vorhanden. Es gibt daher keine belastbare URL, keinen bekannten Startpfad, keine Komponentenliste, keinen Designvertrag und keine produktionsnahe Datenquelle, gegen die jetzt geprüft werden könnte.

Dieser Plan ist deshalb ein ausführbarer Prüfrahmen, **kein** Ergebnisbericht. Er behauptet weder eine funktionierende Website noch E2E-, Accessibility-, Responsive- oder Produktionsreife. Sobald ein Artefakt geliefert wird, müssen URL/Startanweisung und erwartete Kernflüsse in den Testlauf eingetragen werden; unbekannte Punkte bleiben `N/A` statt implizit bestanden.

## 2. Startbedingungen und Testdaten

Vor dem Testlauf dokumentieren:

| Feld | Eintrag | Gate |
|---|---|---|
| Artefakt/URL | `TBD – aus gelieferter Quelle übernehmen` | Ohne überprüfbare Quelle kein E2E-Pass |
| Build-/Preview-ID | `TBD` | Für Screenshot- und Befund-Zuordnung erforderlich |
| Startpfad | `TBD` | Redirects und Deep-Link separat prüfen |
| Bekannte Kernflüsse | `TBD` | Nur gelieferte Anforderungen testen, nichts erfinden |
| Authentifizierung | `nicht vorgesehen / explizit dokumentieren` | Keine privaten Konten oder Secrets in Beweismaterial |
| Testdaten | synthetisch, minimal, nicht personenbezogen | PII-/Secret-Filter vor jedem Screenshot |

Falls die Quelle fehlt, darf nur ein Blocker-Protokoll erstellt werden. Ein HTTP-Status, ein gerendertes Mockup oder eine Konfigurationsdatei gilt nicht als Interaktionsnachweis.

## 3. Testumgebung und Viewports

Die Prüfung erfolgt in einer isolierten Browserinstanz über Codex Computer Use. Browser, Betriebssystem, Zoom, Farbmodus, Netzwerkmodus und Zeitstempel werden je Lauf notiert. Browser-Automation über Orca ist ausgeschlossen.

| Kürzel | Viewport (CSS px) | Zweck | Mindestnachweis |
|---|---:|---|---|
| `VP-XS` | 320 × 568 | enges Mobilgerät, Umbruch/Overflow | Startansicht und ein Kernfluss ohne horizontales Scrollen |
| `VP-S` | 375 × 812 | typisches Mobilgerät | Navigation, Form-/CTA-Bedienung, sichtbarer Fokus |
| `VP-T` | 768 × 1024 | Tablet/Portrait | Layoutwechsel, Touch-Ziele, Dialoge |
| `VP-D` | 1024 × 768 | kleiner Desktop | vollständige Navigation und Fehlerzustände |
| `VP-L` | 1440 × 900 | großer Desktop | Maximalbreite, Inhaltshierarchie, keine Leerräume/Clipping |

Wenn ein Zielgerät nicht exakt einstellbar ist, wird der tatsächlich verwendete Viewport mit `abweichend` markiert; es gibt keinen stillschweigenden Pass.

## 4. Testfälle

Ergebniswerte: `PASS`, `FAIL`, `BLOCKED`, `N/A`. Für jeden Fall werden Start-URL, Viewport, Schritte, erwartetes Ergebnis, tatsächliches Ergebnis, Screenshot-IDs und Befund-ID protokolliert.

### E2E und Interaktion

| ID | Testfall und Schritte | Erwartung / Gate |
|---|---|---|
| `E2E-01` | Quelle öffnen; Startpfad laden; Reload ausführen; direkten Deep-Link (falls geliefert) öffnen | Kein unbehandelter Fehler, kein unerwarteter Auth-/Download-Sprung, Inhalt bleibt nach Reload verfügbar |
| `E2E-02` | Alle sichtbaren Hauptnavigationen nacheinander aktivieren; zurück/vorwärts und Logo/Home prüfen | Jeder gelieferte Link führt zum erwarteten Ziel; aktiver Zustand erkennbar; keine Sackgasse |
| `E2E-03` | Primären Nutzerfluss aus der Anforderung vollständig ausführen (z. B. Auswahl → Eingabe → Bestätigung), nur synthetische Werte verwenden | Jeder Schritt liefert sichtbares Feedback; Erfolg/Fehler sind unterscheidbar; keine unautorisierte Übermittlung |
| `E2E-04` | Pflichtfelder leer lassen; ungültige und Grenzwerte eingeben; korrigieren und erneut absenden | Inline-Fehler sind feldbezogen, verständlich und verschwinden nach Korrektur; Fokus wird sinnvoll gesetzt |
| `E2E-05` | Buttons, Links, Tabs, Menüs, Modals, Tooltips und ggf. Sortierung/Filter bedienen; jeweils öffnen und schließen | Ziel reagiert einmalig und deterministisch; Escape/Schließen funktioniert; kein doppeltes Auslösen |
| `E2E-06` | Ladezustand, langsame/fehlende Antwort (nur wenn kontrolliert simulierbar), Retry/Abbruch prüfen | Kein endloser Spinner ohne Erklärung; Fehler bietet sicheren Wiederherstellungspfad; keine Datenverluste |
| `E2E-07` | Session-/Reload-Grenze prüfen; Datenschutz- und Abmeldeelemente nur ansehen/bedienen, falls geliefert | Keine Secrets in sichtbarer UI oder URL; Logout/Abbruch löscht oder verlässt den Fluss erwartbar |

### Accessibility (manuell beobachtbar, keine automatische Zertifizierung)

| ID | Testfall und Schritte | Erwartung / Gate |
|---|---|---|
| `A11Y-01` | Nur Tastatur: Tab, Shift+Tab, Enter, Space, Escape, Pfeiltasten durch den gesamten sichtbaren Fluss | Jede Aktion erreichbar; Fokusreihenfolge logisch; kein Tastatur-Fang |
| `A11Y-02` | Fokusindikator in heller/dunkler Ansicht und in Modals beobachten; Fokus nach Öffnen/Schließen prüfen | Fokus stets sichtbar und nicht unter Overlay; Rückgabe zum Auslöser nachvollziehbar |
| `A11Y-03` | Überschriften, Landmarken, Link-/Buttonnamen, Fehlermeldungen und Statushinweise visuell auf Eindeutigkeit prüfen | Text beschreibt Zweck/Zustand ohne alleinige Farbcodierung; keine identischen, unklaren CTAs im selben Kontext |
| `A11Y-04` | Zoom auf 200 % (falls Browser unterstützt), anschließend 400 % als Robustheitssicht; Kernfluss wiederholen | Kein wesentlicher Inhalt oder Bedienweg geht verloren; kein unbedienbares horizontales Clipping im Kernbereich |
| `A11Y-05` | `prefers-reduced-motion` aktivieren; Seitenwechsel, Animationen, Autoplay und Toasts beobachten | Bewegung reduziert/abschaltbar; keine Information nur über flüchtige Animation |
| `A11Y-06` | Kontrast/Lesbarkeit und Statusänderungen in normaler und ggf. dunkler Darstellung visuell prüfen | Text, Fokus und Fehlerhinweise bleiben unterscheidbar; Status nicht nur durch Farbe vermittelt |
| `A11Y-07` | Touch-/Pointer-Ziele an `VP-XS`/`VP-S` bedienen, ohne benachbarte Elemente versehentlich auszulösen | Ziele ausreichend getrennt und erreichbar; Sticky UI verdeckt keine Aktion |

Diese manuellen Checks ersetzen kein spezialisiertes Audit. Ein fehlendes Prüfwerkzeug wird als `BLOCKED` oder `N/A` notiert, nicht als Pass.

### Responsive und visuelle Robustheit

| ID | Testfall und Schritte | Erwartung / Gate |
|---|---|---|
| `RWD-01` | Jede Viewport-Größe öffnen; zwischen Größen wechseln; bei Hoch-/Querformat sofern verfügbar prüfen | Kein horizontales Scrollen oder Überlaufen im Hauptinhalt; Header, Navigation und Footer bleiben nutzbar |
| `RWD-02` | Lange Überschriften, lange Labels, leere/gefüllte Zustände und Fehlermeldungen auslösen | Kein Text-Clipping, keine Überlagerung, keine unlesbaren Trunkierungen; Layout bleibt verständlich |
| `RWD-03` | Modal, Dropdown, Tabelle/Karte, Sticky Header und ggf. Seitenleiste an allen relevanten Größen öffnen | Overlay bleibt im Viewport; Schließen und Fokus funktionieren; Inhalte werden nicht verdeckt |
| `RWD-04` | Reload bei jeder Viewport-Größe; Deep-Link (falls vorhanden) direkt laden | Gleicher stabiler Startzustand; keine viewportabhängigen Laufzeitfehler |

## 5. Spätere Browserprüfung mit Codex Computer Use

1. Eine isolierte Codex-Computer-Use-Browserinstanz öffnen und nur die gelieferte URL/Preview verwenden.
2. Vor jeder Eingabe prüfen, dass keine Provider-Ratenbegrenzung oder fremde Login-Anforderung aktiv ist; bei 429/"Too many requests" keine Wiederholung erzwingen.
3. Start- und Browserzustand als Textprotokoll erfassen (URL ohne Tokens, Titel, Viewport, sichtbare Fehlermeldung).
4. Pro Viewport die Fälle in Abschnitt 4 in der Reihenfolge `E2E → A11Y → RWD` durchführen; bei einem Blocker Ursache und letzten reproduzierbaren Schritt festhalten.
5. Nach jeder UI-Änderung Accessibility-Baum/Ansicht frisch lesen; veraltete Element-IDs nicht weiterverwenden.
6. Nur für tatsächlich beobachtete Zustände Screenshots aufnehmen; niemals aus Konfiguration, Quelltext oder HTTP 200 auf Erfolg schließen.
7. Nach Abschluss die Startansicht nochmals laden und prüfen, dass Testdaten, Modals und temporäre Zustände nicht unbeabsichtigt zurückbleiben.

## 6. Screenshot-Anforderungen

### Pflichtaufnahmen

- `00-source-start`: Startansicht mit sichtbarem Titel/URL-Ausschnitt und Viewport.
- `01-nav-<viewport>`: geöffnete Hauptnavigation bzw. aktiver Navigationszustand.
- `02-flow-<step>-<viewport>`: jeder wesentliche E2E-Schritt, einschließlich Erfolg und validiertem Fehlerzustand.
- `03-focus-<viewport>`: sichtbarer Tastaturfokus auf einer repräsentativen Aktion.
- `04-modal-or-overlay-<viewport>`: jeder relevanter Dialog/Overlay-Zustand inklusive Schließmöglichkeit.
- `05-responsive-<viewport>`: repräsentative mobile, Tablet- und Desktopansicht; bei Befund zusätzlich der fehlerhafte Zustand.
- `06-reduced-motion` und `07-zoom-200`: nur wenn diese Varianten tatsächlich geprüft wurden.

### Dateinamen und Metadaten

Format: `YYYYMMDD-HHMMSS_<case-id>_<viewport>_<state>.png` (z. B. `20260921-101500_RWD-01_VP-XS_pass.png`). Zu jeder Aufnahme gehören Browser, CSS-Viewport, Zoom, Fall-ID, Beobachtung und Prüferzeitpunkt in einem Begleitprotokoll. Screenshots werden nicht als Beweis für nicht sichtbare Eigenschaften verwendet.

## 7. Gate-Kriterien

### Freigabe für „interaktiv nachgewiesen“

- Quelle und Startpfad sind reproduzierbar dokumentiert.
- `E2E-01` bis `E2E-05` bestehen für alle gelieferten Kernflüsse in mindestens `VP-S` und `VP-D`.
- Keine offenen `FAIL`-Befunde mit Schweregrad P0/P1; jeder `BLOCKED`-Fall hat einen konkreten Fallback oder ist als Rest-Risiko ausgewiesen.
- Tastaturzugang, sichtbarer Fokus, verständliche Fehler und Modal-Fokus bestehen in den relevanten Flüssen.
- `RWD-01` und `RWD-03` bestehen in `VP-XS`, `VP-T` und `VP-L`.
- Screenshots und Schritte sind frei von Secrets/PII und eindeutig den Fällen zugeordnet.

### Nicht freigeben bei

- nur statischem Rendering, Mockdaten ohne klickbaren Fluss, HTTP 200 oder „sieht gut aus“ ohne Interaktionsnachweis;
- fehlender Quelle, fehlender Kernflussdefinition oder nicht reproduzierbaren Ergebnissen;
- Tastatur-Fang, verdecktem Fokus, nicht bedienbaren mobilen Aktionen, Datenverlust oder ungeklärter Authentifizierung;
- Screenshot mit Token, Cookie, E-Mail, Namen, interner IP, lokalen Pfaden mit sensiblen Segmenten oder personenbezogenen Testdaten.

## 8. Privacy-Filter und Beweishygiene

Vor jeder Aufnahme/Weitergabe:

- URL auf Query-/Fragment-Tokens, E-Mail-Adressen, IDs und interne Hostnamen prüfen; sensible Teile schwärzen oder die Aufnahme verwerfen.
- Keine Passwörter, API-Keys, Cookies, Local-Storage-Inhalte, QR-Codes, Zahlungs- oder Gesundheitsdaten erfassen.
- Nur synthetische Testnamen und Werte verwenden; vorhandene reale Daten nicht öffnen oder exportieren.
- Browserprofil, Downloads, Clipboard und Autofill nicht als Testdatenquelle verwenden.
- Bei einem versehentlichen Secret-Fund: Aufnahme löschen, Ereignis lokal als `PRIVACY-BLOCKED` protokollieren und den Fluss abbrechen; Secret nicht in Befundtext kopieren.

## 9. Fallback- und Blocker-Pfade

| Situation | Vorgehen | Ergebnisstatus |
|---|---|---|
| Keine URL/kein Artefakt geliefert | Nur fehlende Eingangsdaten und betroffene Fälle dokumentieren; keine Behauptung | `BLOCKED` |
| Preview lädt nicht / DNS-/Serverfehler | Einmal reproduzierbar neu laden, URL/Fehlertext ohne Geheimnisse erfassen; keine Retry-Schleife | `BLOCKED` |
| Codex Computer Use oder macOS-Berechtigung fehlt | Computer-Use-Blocker mit konkreter fehlender Fähigkeit melden; nicht auf Orca/andere GUI-Automation ausweichen | `BLOCKED` |
| Viewport/Zoom technisch nicht einstellbar | Tatsächliche Maße notieren und nächstmögliche Größe verwenden; Abweichung markieren | `BLOCKED` bis explizit bewertet |
| Login/Entitlement erforderlich | Nicht raten, keine privaten Konten verwenden; Test auf öffentlich zugängliche Oberfläche begrenzen | `BLOCKED` |
| CAPTCHA, Rate-Limit oder externe Nebenwirkung | Nicht umgehen und nicht wiederholen; sichtbaren Zustand dokumentieren | `BLOCKED` |
| Screenshot enthält sensible Daten | Aufnahme verwerfen und Ersatzaufnahme mit synthetischen Daten erstellen; sonst kein Beweis | `PRIVACY-BLOCKED` |

## 10. Ergebnisprotokoll (pro Lauf ausfüllen)

```text
Lauf-ID:
Quelle/Build:
Browser + OS:
Getestete Viewports:
Ausführungszeitraum:
PASS:
FAIL (mit Befund-ID):
BLOCKED (mit Ursache/Fallback):
N/A (Begründung):
Screenshot-IDs:
Privacy-Check: PASS / PRIVACY-BLOCKED
Freigabe-Gate: PASS / FAIL / BLOCKED
Offene Risiken:
```

**Stop-Bedingung:** Der Lauf endet nach vollständiger Abdeckung der gelieferten Kernflüsse und Viewports oder sobald ein nicht sicher überwindbarer Blocker erreicht ist. Bis dahin bleiben nicht ausgeführte Fälle ausdrücklich `nicht geprüft`.
