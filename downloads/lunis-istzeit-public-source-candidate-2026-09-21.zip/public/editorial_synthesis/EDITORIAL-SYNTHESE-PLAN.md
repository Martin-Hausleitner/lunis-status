# Editorial-Syntheseplan · Lunis Ist-Zeit Showcase

**Stand:** 21. September 2026. Dies ist eine redaktionelle Auswahl- und Abnahmevorlage, kein neuer Produkt- oder E2E-Nachweis. Grundlage sind ausschließlich der aktuelle Hand-off und die unten genannten Reports.

## 1. Ziel und Leitlinie

Der Showcase zeigt (1) sichtbare, vorführbare Oberflächen, (2) nachvollziehbare Provenienz und (3) offene Risiken. Ein grüner Unit-Test ist kein Browser-Beweis; ein statischer Prototyp ist kein laufendes Backend; eine öffentliche URL ist kein Produktionsnachweis. Jede Aussage bekommt daher Belegtyp und Status.

## 2. Quellenbasis

Primärquellen:

- `HANDOFF-NEXT.md` und `work/lunis-istzeit-odoo/docs/HANDOFF-2026-09-20.md`: Frist, öffentliche Seite, offene Befunde, Privacy-/Versandgrenzen.
- `docs/zwischenberichte/ZB-01-D1-design.md`: D1-Stand, 2/24 Browser-Proofs, ungemergter Zweig und offene Gates.
- `docs/zwischenberichte/ZB-02-testlage.md`: 1.142 Testläufe, 2/10 echte E2E-Szenarien, fehlender Stunden-zu-Euro-Nachweis.
- `docs/zwischenberichte/ZB-05-risiken-status.md`: 29 bestätigte Risiken, 26 offen.
- `docs/zwischenberichte/ZB-07-kaufmaennisch.md`: im Browser gezeigte Kernabläufe und Einschränkungen.
- `docs/zwischenberichte/ZB-08-ablage-und-doku.md`: Ablage- und Dokumentationsgrenzen.
- `docs/zwischenberichte/ZB-12-gesamtbericht.md`: konsolidierte Zahlen und Claim-Grenzen.
- `docs/zwischenberichte/ZB-13-methode.md`: Rehearsal-/Dispatch-Provenienz und D1/S08F-Regelverstoß.
- `docs/zwischenberichte/ZB-15-werkindex.md`: Repo-/Showcase-Inventar und Sichtbarkeit.
- `docs/AUSFUEHRUNGSBERICHT-2026-09-20.md`: Modellrollen, Ablauf und Testumgebung.

Nicht verwenden: Transkripte, `intake/`-Rohmaterial, vertrauliche Leistungsnachweise, Screenshots ohne Ergebnisdatei, laufende Prozesse oder ältere Stände ohne Abgleich zum Hand-off.

## 3. Auswahlregeln

### Priorität A — zuerst zeigen

| Beispiel | Zulässige redaktionelle Aussage | Mindestbeleg |
|---|---|---|
| `lunis-status` | öffentliche Statusseite aus Zwischenberichten; nicht „Produktionsmonitor“ | Hand-off-URL, ZB-15, aktueller Filter-/Schwärzungsstand |
| Odoo-Kernabläufe | Stempeln, Prüfen/Freigeben/Buchen/Stornieren und Wochen-Pivot sind für die in ZB-07 genannten Blöcke im Browser gezeigt | ZB-02/ZB-07 plus aktueller Proof/Screenshot |
| Kiosk/Kolonne/Terminal/Telefon/Papier/Fremdmonteur | Erfassungswege als einzelne Use-Case-Kästen; nur belegte E2E-Details nennen | ZB-02 E1/E3/P-E4 und Kiosk-Tours |
| `Luna-Line`, `Luna-Stage`, `Luna-Raum`, `Luna-Korpus` | öffentliche Showcase-Repositories; nicht mit dem Odoo-Produktkern gleichsetzen | ZB-15 Repo-/Sichtbarkeitstabelle |

### Priorität B — nur mit Label

- Brand-Studio und Logo-Schau: nur nach konkreter Repo- und Kundenname-Prüfung; ZB-15 nennt sie als potenziell öffentlich.
- Kundennamenfreie `lunis-zeit-pwa`: erst nach Asset-/Repo-Bereinigung.
- D1 (`shot/D1`): nur als „Designzweig/in Arbeit“; laut ZB-01 ungemergt, 2/24 Browser-Proofs.
- S09/Odoo-17-Material: nur als technische Belegbox des dokumentierten Laufs, nicht als Aussage über den aktuellen 18er `master`.

### Ausschlussregeln

- Varianten mit Kundenname in Dateiname, Titel, Screenshot oder Inhalt.
- Private Odoo-/Fullstack-Repositories als öffentliche Demo; sie bleiben interne Provenienzquellen.
- `WAWI-V2`/`WAWI-STUDIO-ONESHOTS`, solange der Kundenprojektbezug laut ZB-15 unklar ist.
- ZIP-/Archivstände ohne reproduzierbaren aktuellen Lauf oder eindeutige Herkunft.
- Transkripte, Rohaufzeichnungen, Namen, Zugangsdaten, Demo-Passwörter, Leistungsnachweise und interne Connector-/Dispatch-Details.
- Fremde Konkurrenzbilder, fremde Marken-/Wortlautkopien und OrgaCalc-Material.
- D1-Ansichten, Tests oder Claims als „fertig“, „in `master`“ oder „produktionsreif“.

## 4. Provenienz- und Kopierregister

Für jedes Beispiel wird vor dem Schreiben ein Eintrag geführt:

| Feld | Pflichtinhalt |
|---|---|
| `artifact_id` | stabiler Name, z. B. `SHOW-ODOO-CORE` |
| `source_path` | exakter Pfad oder Repo/URL aus Report/Hand-off |
| `visibility` | `public`, `private`, `internal-only` oder `unknown` |
| `state` | `merged/current`, `unmerged`, `prototype` oder `archive` |
| `origin` | `new`, `adapted`, `copied/reused`, `upstream/dependency` oder `unknown` |
| `evidence` | Report + Abschnitt/Zeile, Proof-Datei oder Repo-Inventar |
| `allowed_use` | `show`, `show-with-label` oder `exclude` |
| `privacy_check` | Ergebnis und Datum |

„Kopiert“ nur schreiben, wenn eine konkrete Übernahme belegt ist. Bei Odoo-/Framework-Bestandteilen lautet die sichere Formulierung „auf Odoo 18 Community aufbauend“ bzw. „native Mechanismen wiederverwendet“, nicht „vollständig eigenentwickelt“. Der Ausführungsbericht belegt Claude als Manager/Prüfer, GPT 6 Pro als Bau-Modell und Codex-Agenten für Fleißarbeit; daraus folgt kein Urheber- oder Qualitätsclaim.

Jedes Bild erhält `captured_at`, Branch/Commit, `proof_kind` (`browser`, `unit`, `static`, `report-only`) und Freshness. Fehlt eines, ist es Kontext, kein Beweis.

## 5. Claim-Language

### Erlaubt

- „Im aktuellen Bericht dokumentiert …“
- „Für diesen Ablauf liegt ein Browser-Beleg vor …“
- „1.142 automatische Testläufe ohne Fehler; Browser-Abdeckung ist davon getrennt.“
- „Der Designzweig ist nicht als `master`-Stand abgenommen.“
- „Öffentliches Repository laut Werk-Index; Produktzugehörigkeit wird separat ausgewiesen.“
- „Auf Basis von Odoo 18 Community und vorhandenen nativen Mechanismen.“

### Gesperrt oder nur bedingt

| Nicht schreiben | Stattdessen |
|---|---|
| „fertig“, „produktionsreif“, „sicher“ | aktuellen Kernstand mit offenen Befunden nennen |
| „alle Funktionen bewiesen“ | konkrete Browser-Abläufe und verbleibende Testtypen nennen |
| „1.142 E2E-Tests“ | „1.142 Testläufe; 2/10 geplante E2E-Szenarien echt im Browser“ |
| „Kostenberechnung funktioniert“ | exakten Stunden-zu-Euro-Test als fehlend nennen |
| „PIN geschützt“ | PBKDF2 vorhanden, Klartextprüfung laut Risiko-Report offen |
| „eigenentwickelt/ohne Kopien“ | Provenienzregister verwenden |
| „öffentlich verfügbar“ | nur nach Repo-/URL- und Privacy-Prüfung |

Zahlen als `gemessen`, `geschätzt` oder `aus Report übernommen` markieren. 30–60 € Werkzeugkosten und Personalaufwand nie als ROI- oder Preisversprechen formulieren.

## 6. Sichtbare Risiken und ehrliche Grenzen

Als fester „Stand heute“-Kasten aufnehmen:

1. `sale_rate` wirkt laut ZB-02 nicht auf `full_cost`; der exakte Stunden-zu-Euro-Pfad ist nicht end-to-end getestet.
2. Kiosk-PIN wird laut Hand-off/ZB-05 im Klartext geprüft; PBKDF2 ist ungenutzt.
3. Datenbank-Passwort liegt laut Hand-off in der Git-Historie.
4. 29 bestätigte Risiken, 26 offen; keine Behebung behaupten.
5. Kalender-/Graph-/Kanban-Ansichten aus D1 nicht als `master`-Abnahme ausgeben.
6. Browser-Beweis strikt von Unit-/HTTP-Test trennen.
7. D1/S08F wurden laut ZB-13 ohne grünes Rehearsal dispatcht; das ist Methodenrisiko, kein Erfolgssignal.

Jeder Punkt erhält Quelle, Datum, Auswirkung und Status `offen`/`belegt`/`nicht geprüft`.

## 7. Privacy- und Zwei-Leser-Abnahme

- Keine Kunden-/Mitarbeiternamen, E-Mail-Adressen, Passwörter, Tokens, Datenbank-URLs oder privaten Dateinamen.
- Keine Transkriptzeilen, Rohaufzeichnungen, Leistungsnachweise oder Demo-Passwörter.
- Nur freigegebene öffentliche Repositories/Seiten verlinken; private Quellen bleiben lokal.
- Screenshots auf URL, Tabtitel, Nutzername, IDs und Beispieldaten prüfen.
- Unklare Herkunft, Sichtbarkeit oder Kundenbezug führt zu `exclude`.
- Zwei Leser vermerken Datum, Initialen, Artefaktliste und `GO`, `GO mit Label` oder `NO-GO`.

## 8. PDF-Export-Gate

Der Export ist erst abnahmefähig, wenn:

1. der Bericht nur freigegebene Showcase-IDs und Quellen enthält;
2. Claims eine Quelle oder „redaktionelle Einordnung“ tragen;
3. Privacy- und Zwei-Leser-Gate `GO`/`GO mit Label` sind;
4. der vorhandene PDF-Weg (z. B. `tools/md2pdf.py`) mit eindeutiger Eingabe-/Ausgabeversion läuft;
5. jede PDF-Seite visuell geprüft ist: keine abgeschnittenen Tabellen, leeren Seiten, überlaufenden Codeblöcke oder unlesbaren Links;
6. extrahierter Text gegen Markdown geprüft ist, inklusive Zahlen, URLs, Risiko- und Provenienzbox;
7. Metadaten Titel, Standdatum und Version tragen, aber keine lokalen Pfade, Geheimnisse oder Kundennamen;
8. PDF-Hash und Eingabeversion im Abnahmeprotokoll stehen.

`GO` bedeutet inhaltlich, technisch und privacy-seitig sauber; `GO mit Label` erlaubt klar markierte Prototyp-/Designzweig-/Report-only-Beispiele; `NO-GO` gilt bei fehlendem Beleg, Privacy-Fund, veraltetem Screenshot oder Claim-Überdehnung.

## 9. Ergänzende Index- und Leserlagen

### Hard-M-11 / Kira Garage / CAD / EDV-Hausleitner / Lunis

Diese Begriffe werden als eigene Indexrubriken geführt, nicht zu einem Produktverbund
zusammengezogen. Im aktuellen Hand-off/ZB-15 ist `kira-garage/garage` als privat trotz
Showcase-Bezeichnung markiert; `edv-hausleitner` und `edv-hausleitner-odoo` sind privat.
Der OrgaCalc-/CAD-Plan bleibt eine Recherche-/Planungsquelle: konkrete CAD-Dialekte,
Maschinen und Lizenzen sind laut `docs/ORGAKALK-ODOO-PLAN.md` nicht verifiziert.
Für „Hard-M-11“ liegt in der aktuellen Quellenliste kein belastbarer Eintrag vor;
deshalb wird der Begriff als **offener Indexschlüssel** geführt und nicht inhaltlich
ausgefüllt. Keine Verbindung zwischen Kira, CAD, EDV-Hausleitner und Lunis behaupten,
solange kein Report sie belegt.

Der Hand-off nennt außerdem R133 (Odoo-Demo) als laufende/noch einzusammelnde Lane,
aber im geprüften Quellenbestand liegt kein eigener R133-Abschlussbericht vor. Deshalb
keine R133-Demo als abgeschlossenes Showcase aufnehmen; vorhandene lokale Demo-Proofs
bleiben bis zur Zuordnung `report-only`.

### Nicht-IT-Leserschicht

Der Bericht bekommt pro Showcase eine kurze Alltagserklärung: „Was sieht eine Person,
welche Handlung ist belegt, was ist noch offen?“ Fachbegriffe (Addon, ORM, E2E,
Rehearsal, Branch, Hash) stehen erst in einer technischen Randspalte. Die Zahlenbox
trennt klar: **35,0 Beratungsstunden** (kaufmännischer Report), **≈38,0 Brutto-Agentenstunden**, **≈16,4 überlappungsfreie Stunden** (ZB-09), **11,7 Stunden Wanduhrzeit** aus dem Ausführungsbericht. Abweichende Messdefinitionen werden direkt
am Wert erklärt; keine Zahl als „gesparte Arbeitszeit“ umetikettieren.

### Branding-Evolution und rekonstruierte Labels

Branding wird als zeitliche Entwicklung aus vorhandenen Artefakten beschriftet:
„Konzept“, „Prototyp“, „Designzweig“, „aktueller Stand“. Rekonstruierte oder aus
Dateinamen abgeleitete Labels erhalten den Zusatz **„redaktionell rekonstruiert“**
und einen Quellenverweis; sie werden nicht als ursprünglicher Kundenwortlaut
ausgegeben. Logos, Farben und Brand-Tokens aus D1 dürfen als Designbeleg erscheinen,
aber nicht als Beweis einer abgenommenen CI oder einer fertigen Oberfläche.

### Download-/Quellenzentrum

Ein möglicher Quellen-/ZIP-Bereich wird nur als Index geplant. Jede Zeile benötigt:
`artifact_id`, Dateiname, Größe, SHA-256, Standdatum, Lizenz-/Rechtehinweis,
Provenienz, `public/private`, Privacy-Check und Freigabestatus. Hash und Größe werden
frisch aus der tatsächlich exportierten Datei berechnet, nicht aus Dateinamen oder
älteren Inventaren. Öffentliche Links dürfen nur auf freigegebene Repositories/URLs
zeigen; private oder unklare ZIPs bleiben als „intern, nicht herunterladen“ markiert.
Für Drittmaterie gilt: keine Original-PDFs, Screens oder Wortlautkopien; nur eigene
quellenmarkierte Zusammenfassungen. Ein Quellenzentrum wird erst nach dieser
Metadaten- und Lizenzprüfung in den PDF-Bericht aufgenommen.

## 10. Stop-Kriterium

Fertig ist die redaktionelle Arbeit erst, wenn das Register vollständig ist, jedes Beispiel eine Auswahlentscheidung besitzt, die Grenzenbox sichtbar ist, zwei Leser die Markdown-Fassung abgenommen haben und der PDF-Export alle Gates erfüllt. Bis dahin werden keine bestehenden Sites/Reports geändert, nichts veröffentlicht, kein Push ausgeführt und keine Mail erstellt oder versendet.
