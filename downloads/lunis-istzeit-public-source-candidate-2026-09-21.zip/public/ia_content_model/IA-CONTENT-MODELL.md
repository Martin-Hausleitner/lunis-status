# Informationsarchitektur und Content-Modell

## Zweck und Geltungsbereich

Diese Spezifikation beschreibt die Informationsarchitektur für die professionelle
Endfassung des Lunis-Ist-Zeit-Berichts und eine daraus ableitbare, öffentliche
Übersichtsseite. Sie ist ein redaktionelles Modell, keine neue Produkt- oder
Abnahmebehauptung. Alle Fakten müssen aus den vorhandenen Hand-off-/Report-
Artefakten belegt werden; nicht belegte Werte bleiben als Platzhalter stehen.

**Quellstand für die Redaktion:** PR1-Bericht, Bestandsaufnahme 20.09.2026,
23:04:21 Europe/Vienna, technischer Basisstand `0c1c023a8c66ccc5b6bc3cf3e13a108d9fabc3b0`.
Der Bericht datiert die Ausgabe, nicht einen späteren Testlauf oder eine
Kundenabnahme.

Primäre Quellen im Repository:

- `work/wt/PR1/docs/PROFESSIONAL-REPORT-2026-09-21.md` (führender Bericht)
- `work/wt/PR1/docs/PROFESSIONAL-REPORT-2026-09-21-kurz.md` (Entscheidungsvorlage)
- `work/wt/PR1/docs/report-assets/PR1-facts.md` und `PR1-glossary.md`
- `work/wt/PR1/docs/report-assets/PR1-conflicts.source.md` (Konfliktbehandlung)
- `work/wt/PR1/docs/report-assets/PR1-late-evidence.md` (späte Evidenz)
- `work/wt/PR1/docs/AUDIT-SYNTHESE-2026-09-20.md`, `docs/STATUS-2026-09-20.md`
- `work/wt/PR1/docs/BERICHT-ANSICHTEN-DESIGN-2026-09-20.md`
- Belege unter `work/wt/PR1/.proof/` nur mit zugehörigem Ergebnis-/Metadatensatz.

## Leser und Kernfragen

| Leser | Einstiegsfrage | Gewünschte Entscheidung/Handlung |
|---|---|---|
| Geschäftsführung/Management | Was ist heute belastbar, welches Risiko bleibt und was soll als Nächstes freigegeben werden? | Leistungsnachweis einordnen, begrenzte Erprobung mit Rollen/Daten/Abbruchbedingungen freigeben oder zurückstellen. |
| IT/Betrieb | Welche Bausteine, Nachweise, Grenzen und Betriebsaufgaben gibt es? | Gemeinsamen Übergabestand, Sicherheitsprüfung, Geld-/Rundungsprüfung, Sicherung und Wiederanlauf planen. |
| Markt-/Partnerleser | Welches Problem löst Lunis, für wen, und was ist ausdrücklich noch keine Zusage? | Leistungsumfang verstehen, Demo/Erprobung anfragen; keine Produktions- oder ROI-Zusage aus Marketingtext ableiten. |

Redaktionelle Regel: Eine Aussage darf nur in einem Leserpfad als Tatsache
erscheinen, wenn sie dieselbe Quelle, denselben Bezugsstand und dieselbe
Grundgesamtheit nennt. Historische Testausführung, Testdefinition,
Browserbeleg, Demo-Datenbank und Produktionsfreigabe werden nie gleichgesetzt.

## Seitenbaum für Bericht und Website

```text
Lunis Ist-Zeit
├── Start / Entscheidung auf einen Blick
│   ├── Statussatz und Bezugsstand
│   ├── vier getrennte Kennzahlen
│   ├── Belegampel und Grenzen
│   └── CTA: begrenzte Erprobung / vollständigen Bericht öffnen
├── Für die Geschäftsführung
│   ├── Lage in fünf Sätzen
│   ├── Lieferumfang heute / keine Zusage
│   ├── Zahlen, Kosten und Nutzenhypothese
│   ├── Risiken und offene Entscheidungen
│   └── 14-Tage-Fahrplan mit Abnahmepunkten
├── Für IT und Betrieb
│   ├── System- und Modulkarte
│   ├── Rollen, Datenflüsse und fachliche Grenzen
│   ├── Nachweisregister (Logik / Integration / Browser / Demo)
│   ├── Sicherheit, Geldbewertung und Betriebsfähigkeit
│   ├── Sicherung, Wiederherstellung und Migration
│   └── bekannte Konflikte und Reproduktionsaufträge
├── Für Markt und Partner
│   ├── Problem und Zielgruppen
│   ├── belegte Nutzungsszenarien
│   ├── Demo-Screens / kurze Erklärungen
│   ├── Abgrenzung zur vollständigen kaufmännischen Lösung
│   └── Erprobung anfragen
├── Nachweise und Quellen
│   ├── Faktenregister F01–F60
│   ├── Bild-/Ergebnisregister
│   ├── Glossar
│   └── Quellenkonflikte und spätere Evidenz
└── Offene Punkte / nächste Prüfung
    ├── priorisierte Prüfaufträge
    ├── Verantwortliche und Zieltermin [PLATZHALTER]
    └── Änderungsstand / Freigabestatus [PLATZHALTER]
```

Die Website zeigt nur die kurzen, nicht vertraulichen Ausschnitte aus den
Seiten „Start“, „Markt/Partner“ und ausgewählten Nachweisen. Die vollständigen
Risiko-, Kosten- und Betriebsdetails bleiben im professionellen Bericht bzw.
privaten Übergabepaket. Kundenname, echte Zeitdaten, Zugangsdaten und
Transkriptinhalte sind nicht in den öffentlichen Content zu übernehmen.

## Leserpfade

### Management-Pfad (3–7 Minuten)

`Start` → `Lage in fünf Sätzen` → `Lieferumfang heute / keine Zusage` →
`Zahlen und Kosten` → `Risiken` → `Entscheidungen jetzt`.

Jede Seite endet mit genau einer Entscheidung oder einem überprüfbaren
Nächsten Schritt. Der Pfad muss klar sagen: 40 Stunden und 6.000 Euro netto
sind ein zugeordneter Leistungsnachweis bzw. eine rechnerische Rechnungsbasis,
nicht unabhängig gemessene Zeit bzw. Zahlung; 1.142 Ausführungen sind ein
historischer Prüflauf, keine Funktionsquote.

### IT-/Betriebspfad (10–20 Minuten)

`Start` → `System- und Modulkarte` → `Nachweisregister` → `Sicherheit,
Geldbewertung und Betrieb` → `Sicherung/Wiederherstellung/Migration` →
`Konflikte und Reproduktionsaufträge`.

Der Pfad muss pro technischer Aussage die Version, den Arbeitsstand, die
Prüfumgebung und die Beweisart zeigen. Ein Screenshot ohne Ergebnisdatei gilt
nicht als vollständiger E2E-Nachweis.

### Markt-/Partnerpfad (2–4 Minuten)

`Start` → `Problem und Zielgruppen` → `belegte Nutzungsszenarien` →
`Abgrenzung` → `Erprobung anfragen`.

Keine Superlative („produktionsreif“, „vollständiger Ersatz“, „garantierte
Einsparung“) ohne eine neue, explizit freigegebene Quelle. Die externe
Erfassung mit internem Betrag 0 Euro ist als internes Bewertungsverhalten zu
erklären, nicht als Aussage über eine Lieferantenrechnung.

## Inhaltsblöcke und Datenmodell

Jeder Block besteht aus Inhalt, Evidenz und Geltungsgrenze. Die folgende Form
ist für Markdown, Website-Komponenten und spätere PDF-Erzeugung gemeinsam zu
verwenden.

| Block-ID | Inhalt / Zweck | Pflichtfelder |
|---|---|---|
| `hero_status` | Titel, Stand, Statussatz, primäre Handlungsaufforderung | `title`, `as_of`, `technical_basis`, `status`, `cta`, `source_ids` |
| `metric_band` | Bis zu vier getrennte Kennzahlen | `label`, `value`, `unit`, `reference_class`, `source_id`, `caveat` |
| `executive_summary` | Max. fünf Sätze für Management | `claim`, `decision_relevance`, `source_ids`, `not_claimed` |
| `scope_matrix` | Heute greifbar vs. noch keine Zusage | `area`, `available_claim`, `evidence_ids`, `excluded_claim` |
| `scenario_card` | Ein konkreter Ablauf/Demo-Fall | `scenario_id`, `actor`, `precondition`, `steps`, `observed_result`, `evidence_ids`, `database_scope` |
| `system_card` | Modul-/Schnittstellenübersicht | `module`, `responsibility`, `version`, `dependency`, `source_id`, `operational_boundary` |
| `evidence_row` | Einzelner Nachweis | `evidence_id`, `kind`, `path`, `captured_at`, `environment`, `scope`, `result`, `limitations` |
| `risk_row` | Risiko mit betrieblicher Folge | `risk_id`, `theme`, `severity_word`, `evidence_ids`, `impact`, `next_test`, `owner` |
| `cost_row` | Kosten/Schätzung getrennt nach Art | `cost_type`, `amount`, `basis`, `verified` (ja/nein), `source_id`, `exclusions` |
| `decision_row` | Entscheidung und Freigabegrenze | `decision`, `basis`, `approver`, `deadline`, `released_scope`, `not_released_scope` |
| `timeline_row` | Zeitraum mit Ergebnis und Gate | `window`, `target_result`, `prerequisite`, `owner`, `date_status` |
| `source_note` | Quellen- und Konflikthinweis | `source_id`, `path`, `snapshot_date`, `conflict_class`, `editorial_treatment` |
| `placeholder` | Bewusst fehlende Daten | `field`, `reason_missing`, `requested_from`, `due_date`, `display_policy` |

### Evidenzklassen

- **Browserbelegt:** benannter Screenshot plus zugehörige Ergebnis-/Treiberdatei;
  gilt nur für die ausdrücklich beschriebene Oberfläche/Interaktion.
- **Logiktest:** automatisierte Rechen-/Programmlogik ohne vollständige
  Bedienkette; kein Beleg für Rollen, Netz, UI oder Produktionsdaten.
- **Integration/E2E:** abgegrenzter Ablauf über mehrere Schichten mit
  Gegenprüfung; Datenbank, Version und Testfall müssen genannt werden.
- **Demo-/Snapshot:** vorbereitete Beispiele oder Momentaufnahme; nicht mit
  Kundenmigration, Produktionsverfügbarkeit oder laufendem Scheduler verwechseln.
- **Schätzung/Planannahme:** nur als solche auszeichnen und niemals in eine
  Ist-Zahl oder ein Angebot umetikettieren.

## Pflicht-Evidenzfelder für redaktionelle Freigabe

Vor Veröffentlichung muss jeder faktische Block folgende Felder ausfüllen:

1. `source_id` (F01–F60, R-/ZB-Kennung oder konkreter Pfad)
2. `snapshot_date` und `as_of_timezone`
3. `technical_basis` (Commit/Branch/Arbeitsstand)
4. `evidence_kind` (Browser, Logik, E2E, Demo, Schätzung)
5. `population` (z. B. 37 sichtbare Menüs vs. 48 statische Definitionen)
6. `observed_result`
7. `scope_limit` und `not_proven`
8. `privacy_class` (öffentlich, intern, vertraulich)
9. `review_status` (offen, geprüft, freigegeben)
10. `owner` und `next_check` für offene Befunde.

Ein Bild wird nur gemeinsam mit `path`, `captured_at`, `database_scope`,
`environment`, `scenario_id` und `result_file` verwendet. Fehlt eines dieser
Felder, erscheint es im Bericht als „Illustration/Beispiel“, nicht als
Nachweis.

## Offene Daten-Platzhalter

Diese Felder dürfen im redaktionellen Entwurf sichtbar bleiben; sie dürfen
nicht durch Schätzungen oder implizite Annahmen ersetzt werden.

| Platzhalter | Warum offen | Darstellung bis zur Klärung |
|---|---|---|
| `{{LIVE_STATUS_URL_OR_RELATIVE_PATH}}` | Live-Statusdatei ist im eingefrorenen PR1-Arbeitsbaum nicht vorhanden; Hauptarbeitsverzeichnis führt sie separat. | Link als Integrationshinweis, keine Verfügbarkeitszusage. |
| `{{APPROVER_NAME_AND_ROLE}}` | Verantwortliche für Freigabe, Betrieb und Daten sind nicht im Bericht festgelegt. | „Noch zu benennen“. |
| `{{PILOT_SCOPE_AND_ALLOWED_DATA}}` | Erprobungsdaten, Rollen und Abbruchbedingungen müssen Betreiber festlegen. | Keine Echtdatenfreigabe behaupten. |
| `{{CUSTOMER_INSTANCE_AND_MIGRATION_RESULT}}` | Keine bestätigte Übernahme einer Kundendatenbank im Quellstand. | Migration als offener Prüfauftrag. |
| `{{CURRENT_SECURITY_RETEST}}` | PIN-/Zugangsweg, Netzwerkbindung und Wiederanlauf benötigen aktuelle Gegenprüfung. | Risiko + nächster Test, kein „behoben“. |
| `{{INTEGRATED_EURO_RECONCILIATION}}` | Vollständige Gegenrechnung des Mitarbeiter-Kostenpfads ist offen; interne Kosten, Verkaufssatz und Lieferantenrechnung sind getrennt. | „Nicht unabhängig bestätigt“. |
| `{{MARGIN_OR_REVENUE_SOURCE}}` | Vorhandene Auswertungen sind keine vollständige Erlös-/Margenrechnung. | „Nicht im heutigen Umfang“. |
| `{{BACKUP_RESTORE_EVIDENCE}}` | Sicherung und Wiederherstellung müssen praktisch nachgewiesen werden. | Betriebsrisiko mit Abnahmekriterium. |
| `{{PUBLIC_DEPLOYMENT_URL}}` | Ein Server-/Deploy-Status ist nur zu nennen, wenn die URL aktuell geprüft wurde. | URL ausblenden, bis selbst validiert. |
| `{{DATE_OF_NEXT_REVIEW}}` | Der 14-Tage-Fahrplan ist ein Vorschlag, kein beauftragter Termin. | „Vorschlagsfenster; Verfügbarkeit offen“. |

## Redaktionelle Guardrails

- Zahlen mit verschiedener Grundgesamtheit niemals addieren oder als Quote
  darstellen. Besonders 40 h/6.000 EUR, 1.142 Ausführungen, 764
  Testdefinitionen, 37 sichtbare Menüs und 48 statische Menüdefinitionen
  getrennt beschriften.
- „Heute greifbar“ beschreibt belegte Teilumfänge, nicht eine globale
  Produktionsfreigabe.
- Risikoampel und Belegampel nicht vermischen: Risiko-Schwere in Worten,
  Nachweisstatus als Browser/Logik/E2E/Demo/Schätzung.
- Historische, spätere oder parallele Arbeitsstände nur mit Datum und Quelle
  einbeziehen; spätere Evidenz wird nicht stillschweigend in den PR1-Stand
  eingerechnet.
- Öffentliche Seite: keine Kundennamen, Zugangsdaten, Transkripte, internen
  Pfade oder vertraulichen Leistungsdetails.
- Jede CTA führt zu einer überprüfbaren Handlung (Erprobung anfragen,
  vollständigen Bericht lesen, Prüfauftrag definieren), nicht zu einer
  unbelegten Kauf- oder Einsparungszusage.

## Abnahmekriterien für dieses Content-Modell

- Jede Berichtseite lässt sich einem Leser und einer Kernfrage zuordnen.
- Jeder Faktblock hat Quelle, Stand, Evidenzklasse und Begrenzung.
- Offene Werte sind als `{{...}}` markiert und haben einen Klärungsweg.
- Website-Inhalte sind aus dem Bericht ableitbar, aber ohne vertrauliche
  Details und ohne neue Behauptungen.
- Konflikte werden über die in `PR1-conflicts.source.md` dokumentierte engere
  Aussage behandelt, nicht durch Mittelwertbildung.
- Vor einem URL-/Publish-Handoff wird die konkrete Oberfläche selbst geprüft;
  Datei- oder HTTP-Existenz allein zählt nicht als Ende-zu-Ende-Beleg.

