# Lunis Ist-Zeit — drei Visual-/Designrichtungen

**Zweck:** Auswahlgrundlage für den belegten Endbericht und die kurze Übersichts-Website.
Dies ist ein Designvorschlag, keine Behauptung über bereits ausgelieferte UI. Alle
produktbezogenen Aussagen unten stammen aus vorhandenen lokalen Artefakten; neue
Formen, Abstände und Kompositionen sind als Vorschlag gekennzeichnet.

## Belegbasis und Grenzen

- `research/15-lunis-branding-kit.md`: kanonische Lunis-Basis-Marke ohne Regionalzusatz;
  Logo-Farben `#091A40`, `#FE0942`, `#FFFFFF`; UI-Farben und Systemfont des
  „Lunis Calm“-Frontends; kein belegtes Dark-Mode-System.
- `research/01-repo-inventory.md`: bestehende Funktions- und Evidenzlage, inklusive
  Rohzeit-Ledger, Prüfung/Freigabe, Statusfarben und der Grenze „echter Browser-E2E
  nicht erfolgreich“.
- `research/07-pwa-prototype.md`: belegte Ansichten `map`, `home`, `capture`, `day`,
  `raw`, `week`, `calendar`, `projects`, `planning`, `team`, `paper`, `terminal`,
  `costs`, `sources`, `rules`, `rights`, `exports`, `settings`; Zonen Werkstatt,
  Oberfläche, Büro, Lager, Montage; österreichische deutsche Mikrocopy.
- `work/oneshot-parts/01-kurzfassung.md` und `work/plan-parts/06-variante-a.md`:
  Odoo-Variante, Rohzeit-Ledger neben Timesheet, menschliche Freigabe,
  Wien-Mitternacht-Split und reale Demo-/E2E-Anforderung.
- Vorhandene visuelle Referenz innerhalb des Projekts:
  `work/lunis-istzeit-odoo/site/index.html`, `site/live.html`,
  `site/assets/brand/logo.svg` und `.proof/`-Screenshots. Sie belegen eine
  Sidebar-/Berichtshierarchie und vorhandene Statusampeln, nicht automatisch eine
  abgeschlossene Produktabnahme.

**Nicht behaupten:** eine erfundene Markenstory, ein offizielles Dark Theme, eine
neue Hausschrift, reale Live-Daten aus Screenshots oder erfolgreiche Browser-E2E.
Statuswerte und Kennzahlen werden nur mit Quelle und Stand angezeigt.

## Gemeinsame Leitplanken

1. Die originale Lunis-Basis-Marke bleibt unverändert; kein Ersatzsignet und kein
   Regionalzusatz im Logo.
2. Brand-Rot `#FE0942` gehört primär zum Logo. Interaktive UI nutzt das belegte
   `--accent: #DC2438` mit `--accent-hover: #BF1C31`; beide Rollen werden nicht
   vermischt.
3. Status ist semantisch und textlich: Gut `#2E7250`/`#EDF5EF`, Warnung
   `#875A17`/`#FFF3DC`, Fehler `#C83139`; zusätzlich immer Klartext wie „belegt“,
   „teilweise“ oder „nicht geprüft“.
4. Keine Ampelfarbe als alleinige Information. Kontrastziel: mindestens WCAG AA
   für normalen Text; auf `#F5F6F8`/`#FFFFFF` werden dunkle Texttokens verwendet.
5. Evidenz-Chips tragen Quelle und Datum/Stand, z. B. `research/01 · Bestand`.
   „Konfiguration“, „Screenshot-Proof“ und „E2E bestanden“ sind drei verschiedene
   Zustände.
6. Keine dekorativen Verläufe, Glasflächen, 3D-Illustrationen oder generische
   Stockmotive. Linien-Icons bleiben stroke-basiert (`18–19px`, rund, ca. 1.65px),
   wie im vorhandenen Frontend belegt.
7. Responsive zuerst: die belegte Navigation wird auf kleinen Breiten zu einem
   zugänglichen Menü; Tabellen erhalten Karten-/Zeilenalternative statt
   horizontalem Zwangs-Scrollen.

---

## Richtung A — „Calm Evidence“

**Charakter:** ruhiger, heller Bericht mit hoher Lesbarkeit. Die Seite fühlt sich
wie ein verlässliches Prüfprotokoll an: viel Weißraum, klare Quellen, wenig
Chrom. Das ist die konservativste Fortführung des belegten „Lunis Calm“-Systems
und eignet sich am besten für Partner, die Nachvollziehbarkeit vor Show wollen.

### Design-Tokens

| Token | Wert | Verwendung |
|---|---|---|
| `paper` | `#F5F6F8` | Seitenfläche |
| `surface` | `#FFFFFF` | Berichtskarten, Tabellen, Belege |
| `ink` | `#20282C` | Fließtext und Überschriften |
| `muted` | `#727A80` | Metadaten, Quellenzeile |
| `line` | `#E6E9EC` | Trennlinien |
| `accent` | `#DC2438` | Primäraktion, aktive Navigation |
| `accent-soft` | `#FCECEF` | dezente Hervorhebung |
| `navy-logo` | `#091A40` | ausschließlich Wortmarke; optional dunkler Textanker |
| `good / warn / bad` | `#2E7250 / #875A17 / #C83139` | Status mit Klartext |
| `radius / control` | `18px / 10px` | große Karte / Eingabe und Button |
| `shadow` | `0 3px 12px #1C273003` | sehr leichte Kartenerhebung |

### Layout

- Desktop: `232px` feste Sidebar (belegter Referenzwert), Content maximal etwa
  1120–1200px, linksbündige Lesespur.
- Kopfbereich: Logo, Titel, Stand-/Quellenzeile; darunter vier bis fünf
  Kennzahlenkarten nur, wenn jede Zahl einen Beleg besitzt.
- Hauptspalte als vertikale Beweisfolge: **Ausgangslage → Entscheidung →
  Umsetzungsschnitt → Nachweis → offene Grenze**.
- Berichtskarten verlinken in den Detailbericht; ein „Beleg ansehen“-Link steht
  immer nahe an der Aussage.
- Mobile: Sidebar als Dialogmenü, Karten einspaltig, Tabellen als gestapelte
  Datensätze mit sichtbaren Feldnamen.

### Typografie

- Primär: `-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif`
  (belegt in `public/assets/app.css`; keine neue Webfont).
- H1 `30px / 680`, H2 `17px / 650`, H3 `14px / 650`, Fließtext `14px / 1.55`;
  Quellen `12px / 1.45`.
- Zahlen in KPIs dürfen tabellarische Ziffern nutzen, aber keine übergroßen
  „Marketing“-Zahlen ohne Kontext.

### Kontrast- und Statusregeln

- Primärtext immer `ink` auf `paper` oder `surface`; `muted` nur für sekundäre
  Informationen, nie für Pflichttext.
- Status-Chip kombiniert Farbe, Symbol und Wort: `● PASS`, `△ TEILWEISE`,
  `× NICHT BELEGT`.
- Rot signalisiert Befund/Blockade, nicht „Lunis-Brand“ allein. Logo-Rot bleibt
  auf der Wortmarke begrenzt.

### Beispiel-Komponenten

```text
[Quelle research/01 · Stand 2026-09-20]  E2E nicht bestanden
Der Python-MVP hat 124/124 Tests grün; echter Browser-E2E ist nicht belegt.
[Beleg öffnen] [Grenze anzeigen]
```

- **Evidence Card:** Titel, ein belegter Satz, Status-Chip, Quelle, Link.
- **Decision strip:** „Belegt“, „Vorschlag“, „offen“ als drei gleich große Zustände.
- **Traceability row:** Anforderungs-ID → Umsetzungspunkt → Test/Proof → Restlücke.
- **Quiet KPI:** Zahl, Einheit, Stichtag und Quelle in einer Zeile.

### Auswahlkriterien

Wählen, wenn der Bericht vor allem als prüfbare Übergabe, Partnerunterlage oder
Entscheidungsvorlage gelesen wird. Nicht wählen, wenn ein operatives Cockpit mit
vielen gleichzeitigen Zuständen im Vordergrund steht; dafür sind B oder C besser.

---

## Richtung B — „Navy Ledger / Odoo Bridge“

**Charakter:** ein strukturiertes, Odoo-nahes Arbeitsbild für die Frage „Wie wird
Rohzeit zu freigegebener Ist-Zeit?“. Der visuelle Schwerpunkt liegt auf dem
Ledger, den Übergängen und den Stop-Tests. Navy ist hier eine **vorgeschlagene
Flächenfarbe aus dem belegten Logo-Navy**, kein behauptetes offizielles Dark Theme.

### Design-Tokens

| Token | Wert | Verwendung |
|---|---|---|
| `shell` | `#091A40` | vorgeschlagene dunkle Kopf-/Navigationsfläche |
| `shell-ink` | `#FFFFFF` | Navigation auf `shell` |
| `paper` | `#F5F6F8` | helle Arbeitsfläche für Kontrast |
| `surface` | `#FFFFFF` | Ledger-Zeilen und Panels |
| `ink` | `#20282C` | Text auf hellen Flächen |
| `accent` | `#DC2438` | aktive Aktion / Freigabe-Schritt |
| `accent-hover` | `#BF1C31` | Hover/Fokus, nicht Statusersatz |
| `mint / forest` | `#D6EBD8 / #183827` | Start-/Resume-Aktion aus dem UI-System |
| `line-strong` | `#D6DCE0` | Spalten- und Prozessgrenzen |
| `good / warn / bad` | `#2E7250 / #875A17 / #C83139` | Prozessstatus mit Text |
| `float` | `0 12px 40px #182C361A` | Dialog-/Detailpanel |

### Layout

- Dreizoniges Raster: **Kontext** (links, 208–232px), **Ledger/Timeline** (Mitte),
  **Belegdetails** (rechts, auf Mobile unterhalb).
- Oben ein Prozessband: `Erfasst → Entwurf → Geprüft → Freigegeben → Timesheet`.
  Jeder Übergang hat eine Quelle oder einen Stop-Test; nie „automatisch gebucht“
  suggerieren.
- Rohzeit-Segmente als horizontale Zeilen mit Start/Ende, Person, Projekt,
  Kostenstelle, Quelle, Zustand. Nachtarbeit und Wien-Mitternacht-Split werden
  als sichtbare Teilzeilen markiert.
- Odoo-Bezug als dünne Brückenlinie/Label („native Timesheet-Projektion“), nicht
  als Behauptung einer bereits vollständigen Integration.
- Mobile: Prozessband wird horizontal scrollbar mit `aria-current`; Ledger wird
  zu prüfbaren Karten.

### Typografie

- Systemfont wie in A; für technische IDs und Zeitstempel `ui-monospace,
  SFMono-Regular, Menlo, monospace` nur inline.
- H1 `28px / 680`, Prozesslabels `12px / 650` in Versalien, Ledgertext `13–14px`.
- Keine Monospace-Fließtexte und keine Codeästhetik außerhalb von IDs/Quellen.

### Kontrast- und Statusregeln

- Navy-Flächen nur mit weißem Text und sichtbarem Fokus-Ring; Status-Chips bleiben
  auf hellen Flächen, damit Rot/Grün nicht auf dunklem Navy „glühen“.
- Jede Statusstufe hat zusätzlich eine Verbform: `Rohzeit erfasst`, `Prüfung offen`,
  `Freigabe belegt`, `Projektion nicht nachgewiesen`.
- Der Freigabe-Button ist rot, die startende Zeiterfassung mint/forest; dadurch
  werden „Aktion“ und „Status“ nicht verwechselt.

### Beispiel-Komponenten

```text
ROHZEIT  07:00–15:30  Person A  Projekt 26-014  KST WERK
Quelle: Kiosk · Status: Prüfung offen · Beleg: S05b
[Prüfen] [Korrekturanfrage] [Journal öffnen]
```

- **Ledger row:** unveränderliche Originaldaten links, abgeleitete Werte rechts.
- **Approval stepper:** ein Schritt pro Zustandsübergang; fehlender Proof bleibt
  sichtbar und wird nicht grün gefärbt.
- **Split marker:** lokale Mitternacht als vertikale Linie mit zwei Tageslabels.
- **Bridge card:** Odoo-Modell/Projektionsziel, Feldmapping, Teststatus.

### Auswahlkriterien

Wählen, wenn das Publikum die Odoo-Abbildung, Rollen/Rechte, Freigabe und
Nachweisführung verstehen muss. B eignet sich für technische Abnahmen und
One-Shot-/Stage-Berichte. Nicht wählen, wenn eine leichte, vollständig helle
Leseseite ohne Prozessdichte gewünscht ist; dann A.

**Risiko:** Da die Quellen ausdrücklich kein fertiges Dark-Mode-System belegen,
muss die dunkle Fläche vor einer Umsetzung visuell und mit Kontrastprüfung
abgenommen werden. Sie ist eine Richtung, kein vorhandener Markenstandard.

---

## Richtung C — „Werkstatt-Karte / Betriebscockpit“

**Charakter:** eine helle, handlungsnahe Übersicht, die die belegten Lunis-
Ansichten und Zonen als Betriebsbild lesbar macht. Sie verbindet Karte, Tages-
status und offene Prüfung, ohne eine physische Karte oder reale Live-Belegung zu
erfinden. Der Stil ist freundlicher und räumlicher als A, aber weniger technisch
als B.

### Design-Tokens

| Token | Wert | Verwendung |
|---|---|---|
| `paper` | `#F5F6F8` | Grundfläche |
| `surface` | `#FFFFFF` | Zonen-/Tageskarten |
| `ink` | `#20282C` | Text |
| `muted` | `#596269` | sekundärer Text, stärker als `#727A80` auf kleinen Labels |
| `forest` | `#183827` | aktive/startende Betriebsaktion |
| `mint` | `#D6EBD8` | Hintergrund für aktive/startende Karte |
| `accent` | `#DC2438` | primäre Navigation und Korrekturhinweis |
| `accent-soft` | `#FCECEF` | rote Hinweisfläche |
| `blue` | `#386CA0` | Informationsbadge |
| `good / warn / bad` | `#2E7250 / #875A17 / #C83139` | Status, immer mit Text |
| `line` | `#E6E9EC` | Zonenraster |

### Layout

- Hero mit „Heute / Woche“-Umschalter (aus der belegten `map`-Ansicht abgeleitet),
  Stand und Datenquelle.
- Darunter ein 2×2-Raster: **Jetzt**, **Mein Tag**, **Prüfung offen**, **Projekte**.
- Hauptbereich: abstrakte Zonenkarte mit fünf belegten Zonenlabels (Werkstatt,
  Oberfläche, Büro, Lager, Montage). Keine Personenpunkte oder Zahlen anzeigen,
  wenn kein aktueller Beleg vorliegt; stattdessen „Demo-/Snapshot-Daten“.
- Unterhalb ein „Bewegungsband“ für Start/Pause/Resume/Stop und Reise/Abwesenheit,
  das die `capture`-/`day`-Funktionen erklärt.
- Mobile: Zonen als horizontale Snap-Karten, die vier KPI-Karten in einer Spalte;
  primäre Aktion bleibt am unteren Rand erreichbar.

### Typografie

- Systemfont wie A; Überschriften etwas wärmer durch Gewicht, nicht durch neue
  Schriftfamilie.
- H1 `30px / 680`, Zonenname `15px / 650`, KPI `24px / 680`, Hilfstext `13px`.
- Zahlen immer mit Einheit und Zeitraum: `6:42 h · heute`, nicht nur `6:42`.

### Kontrast- und Statusregeln

- Zonen unterscheiden sich primär über Label, Icon und Position; Farbe ist nur
  sekundäre Orientierung. Das bleibt auch bei Graustufen-/Kontrastmodus lesbar.
- Mint/forest ist ausschließlich „laufende/fortsetzbare Erfassung“; Rot bleibt
  Korrektur-/Fehlerhinweis; Gelb bleibt Prüfbedarf.
- „Live“ wird nur mit aktuellem, direkt erhobenem Zustand beschriftet. Ein
  Screenshot oder Bericht erhält den Zusatz `Snapshot` bzw. `Stand …`.

### Beispiel-Komponenten

```text
WERKSTATT · KST 110
Snapshot: 2026-09-20 · Quelle: PWA-Prototyp / Bericht
Keine aktuelle Live-Belegung belegt
```

- **Zone card:** Zonenname, KST, belegte Funktion, Datenstand, optional Status.
- **Action dock:** Start, Pause, Fortsetzen, Stop; jede Aktion mit kurzer
  Erklärung und „Serverzeit“-/Quelle-Hinweis, nicht mit simuliertem Timer.
- **Day summary:** Ist / gebucht / offen, plus sichtbare Rundungs- und
  Freigaberegel.
- **Consent tile:** Quellen (QR, Terminal, Papier usw.) mit `aktiv`/`nicht
  aktiviert`; das folgt der belegten Opt-in-Registry.

### Auswahlkriterien

Wählen, wenn der Endbericht einen verständlichen Rundgang für Betrieb, Team und
Geschäftsführung braucht und die 19 Ansichten des Prototyps wiedererkennbar sein
sollen. C ist die beste Website-Richtung für eine kurze, menschlich lesbare
Übersicht. Nicht wählen, wenn die primäre Aufgabe eine formale Auditspur ist (A)
oder das Feldmapping im Vordergrund steht (B).

**Risiko:** Eine Karte kann fälschlich nach Live-Betrieb aussehen. Deshalb muss
jede Zonenkarte einen Datenstand und einen Belegtyp tragen; ohne Live-Evidenz ist
„Snapshot“ Pflicht.

---

## Vergleich und Entscheidungshilfe

| Kriterium | A · Calm Evidence | B · Navy Ledger | C · Werkstatt-Karte |
|---|---:|---:|---:|
| Beleg- und Quellenklarheit | sehr hoch | hoch | mittel–hoch |
| Odoo-/Prozessverständnis | mittel | sehr hoch | mittel |
| Operative Anschaulichkeit | mittel | hoch | sehr hoch |
| Nähe zum belegten UI-System | sehr hoch | mittel (Navy-Fläche vorgeschlagen) | hoch |
| Risiko falscher Live-Anmutung | niedrig | niedrig | mittel |
| Geeignet als kurze Website | hoch | mittel | sehr hoch |
| Geeignet als technischer Endbericht | sehr hoch | sehr hoch | mittel |

### Empfohlene Auswahlregel

- **Endbericht:** A als Grundstruktur; B-Komponenten nur für Ledger-/Odoo-Kapitel.
- **Kurze Website:** C als Einstieg; A-Karten für Quellen und Grenzen.
- **Einheitliches One-Shot-Artefakt:** B, wenn die Zielgruppe primär technische
  Abnahme und echte Odoo-E2E-Nachweise erwartet.

Die Empfehlung ist eine Kompositionsentscheidung, keine Aussage über die noch
offene Produktentscheidung Odoo-Fundament versus Python-Plattform/Connector.
Vor Implementierung: eine Richtung auswählen, die verwendeten Tokens gegen
`research/15-lunis-branding-kit.md` prüfen und anschließend echte Browser-/Proof-
Grenzen sichtbar testen. Keine Richtung darf aus einem statischen Preview eine
E2E-Erfolgsmeldung machen.
